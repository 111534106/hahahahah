---
summary: "Alias for session management docs"
read_when:
  - You looked for docs/sessions.md; canonical doc lives in docs/session.md
---
# Sessions

Canonical session management docs live in [Session management](/concepts/session).
