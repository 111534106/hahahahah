---
summary: "Workspace template for BOOT.md"
read_when:
  - Adding a BOOT.md checklist
---
# BOOT.md

Add short, explicit instructions for what OpenClaw should do on startup (enable `hooks.internal.enabled`).
If the task sends a message, use the message tool and then reply with NO_REPLY.
